#! /bin/env

mv java-cup-11b-runtime.jur java-cup-11b-runtime.jar
mv java-cup-11b.jur java-cup-11b.jar
mv jflex-1.6.1.jur jflex-1.6.1.jar

