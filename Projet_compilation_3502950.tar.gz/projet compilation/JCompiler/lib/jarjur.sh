#! /bin/env

mv java-cup-11b-runtime.jar java-cup-11b-runtime.jur
mv java-cup-11b.jar java-cup-11b.jur
mv jflex-1.6.1.jar jflex-1.6.1.jur

