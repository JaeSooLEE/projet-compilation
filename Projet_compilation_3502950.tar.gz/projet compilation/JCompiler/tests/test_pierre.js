lambda(x) {
   let z = 2;
   return lambda (y) {
     return y;
   };
} (2)(3);
