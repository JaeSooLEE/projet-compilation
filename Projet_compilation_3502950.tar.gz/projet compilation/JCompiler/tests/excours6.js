
var x = 20 + 1;
var y = x * 2;
var z = 0;

if (x == y) {
    x = x + 1;
    z = x * 2;
} else {
    y = y - 1;
    z = y * 2;
}

x;
y;
z;
