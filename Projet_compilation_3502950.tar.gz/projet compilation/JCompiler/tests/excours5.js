var x = 42;
var y = 34;
x;
y;
var z = y;
y = 9;
z;
