var add = lambda(a, b) {
            return a + b;
          };

add(2, 3);

