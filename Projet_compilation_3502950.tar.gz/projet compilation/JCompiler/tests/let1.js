let x = 41 + 1;
x;

