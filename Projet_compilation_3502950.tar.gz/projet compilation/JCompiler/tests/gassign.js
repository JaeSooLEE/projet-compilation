var x = 42;
x;
x = 34;
x;

