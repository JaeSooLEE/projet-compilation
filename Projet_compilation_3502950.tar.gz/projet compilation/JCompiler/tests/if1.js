if (true) {
    42;
} else {
    38;
}

