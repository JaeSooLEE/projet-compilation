if (false) {
    42;
} else {
    38;
}

