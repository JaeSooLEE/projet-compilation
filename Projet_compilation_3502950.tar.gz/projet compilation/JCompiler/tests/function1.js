function add(a, b) {
     return a + b;
}

add(2, 3);

