var x = 10;
var z = 100;

let g = lambda (y) { return x * y * z; };

let x = 1000;
let z = 10000;

g(7);
