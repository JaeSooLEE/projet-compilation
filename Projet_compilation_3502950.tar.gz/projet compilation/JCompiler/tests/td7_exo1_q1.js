function foo (x, y) {
    return x + y;
}

foo(3, 4);

var fii = lambda (x, y) { return x + y; };

fii (3, 4);

let fuu = lambda (x, y) { return x + y; };

fuu (3, 4);
