var x = 42;
var y = 34;
x;
z;
var z = y;
z;


