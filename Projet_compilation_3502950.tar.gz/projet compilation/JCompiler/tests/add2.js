function plus(x, y) {
    return x + y;
}

plus(40, 2);

