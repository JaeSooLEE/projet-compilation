var a = print(5);
var b = print(true);
var c = print(false);
