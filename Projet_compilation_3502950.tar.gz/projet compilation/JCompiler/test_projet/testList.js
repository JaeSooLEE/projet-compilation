var l2 = cons(1,cons(1, nil));
var l = liste(1, 2 ,3 ,4 ,5);
var p = print(l2);
var p2 = print(l);
var maliste = [1, [2, [ 4, nil]]] ;
function length(l) {if (l == nil) {return 0;} else {return (1 + (length(cdr(l))));}}
length(maliste) ;
