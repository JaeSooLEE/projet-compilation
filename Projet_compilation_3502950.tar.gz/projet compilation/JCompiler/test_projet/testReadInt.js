var a = readInt();
a;
