var p = cons(3, 4);
var [c, d] = cons(1,2);
var [a, b] = p;
var ap = print(a);
var bp = print(b);
var cp = print(c);
var dp = print(d);
