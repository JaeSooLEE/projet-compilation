var p = [2,3];
let [a, b] = p;
var pr = print(a);
var pb = print(b);
