package microjs.jcompiler.middleend.kast;

import java_cup.runtime.ComplexSymbolFactory.Location;

public class KPVar extends KStatement {
    private String name1;
    private String name2;
    private KExpr car;
    private KExpr cdr;

    public KPVar(String name1, String name2, KExpr car, KExpr cdr, Location startPos, Location endPos) {
    	super(startPos, endPos);
    	this.name1 = name1;
      this.name2 = name2;
		this.car = car;
    this.cdr = cdr;
    }

    @Override
    public void accept(KASTVisitor visitor) {
    	visitor.visit(this);
    }

	public String getName1() {
		return name1;
	}

  public String getName2(){
    return name2;
  }

	public KExpr getCar() {
		return car;
	}

  public KExpr getCdr(){
    return cdr;
  }
}
