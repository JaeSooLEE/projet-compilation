package microjs.jcompiler.backend.bytecode;

import microjs.jcompiler.backend.Serializer;

public class Liste extends BCValue{
	private int value;

	public Liste(int value) {
		this.value = value;
	}

	@Override
	public int getOpcode() {
		return 7;
	}

	@Override
	public String getOpcodeName() {
		return "LISTE";
	}

	@Override
	public void genBytecode(Serializer gen) {
		gen.encode(getOpcode());
	  if(value == 0){
      gen.encode(0);
    }else{
      gen.encode(1);
    }
	}

	@Override
	public int getSize() {
		return 2;
	}

	public String toString() {
    if (value == 0){
      return "NIL";
    } else {
      return "LISTE";
    }
	};
}
