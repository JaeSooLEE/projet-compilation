package microjs.jcompiler.frontend.ast;

import java_cup.runtime.ComplexSymbolFactory.Location;
import microjs.jcompiler.middleend.kast.KPair;
import microjs.jcompiler.utils.DotGraph;
import microjs.jcompiler.middleend.kast.KExpr;
import microjs.jcompiler.middleend.kast.KEVar;
import microjs.jcompiler.frontend.ast.Expr;
import microjs.jcompiler.middleend.kast.KCall;
import java.util.ArrayList;
import java.util.List;



public class PairConst extends Expr {
	private Expr car;
  private Expr cdr;

	public PairConst(Expr car, Expr cdr, Location startPos, Location endPos) {
		super(startPos, endPos);
		this.car = car;
    this.cdr = cdr;
	}

	@Override
	public KCall expand() {
		List<KExpr> args = new ArrayList<>();
    args.add(car.expand());
		args.add(cdr.expand());
		return new KCall(new KEVar("cons", getStartPos(), getEndPos()), args, getStartPos(), getEndPos());
	}

	@Override
	protected String buildDotGraph(DotGraph graph) {
		String intNode = graph.addNode("Pair(" + car + ", " + cdr + ")");
		return intNode;
	}

	@Override
	protected void prettyPrint(StringBuilder buf) {
		buf.append(car);
    buf.append(cdr);
	}
}
