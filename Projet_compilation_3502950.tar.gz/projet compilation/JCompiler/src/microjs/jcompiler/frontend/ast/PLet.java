package microjs.jcompiler.frontend.ast;

import java.util.ArrayList;
import java.util.List;

import java_cup.runtime.ComplexSymbolFactory.Location;
import microjs.jcompiler.middleend.kast.KCall;
import microjs.jcompiler.middleend.kast.KClosure;
import microjs.jcompiler.middleend.kast.KExpr;
import microjs.jcompiler.middleend.kast.KReturn;
import microjs.jcompiler.middleend.kast.KSeq;
import microjs.jcompiler.middleend.kast.KStatement;
import microjs.jcompiler.utils.DotGraph;
import microjs.jcompiler.middleend.kast.KEVar;
import microjs.jcompiler.frontend.ast.Expr;


public class PLet extends Statement {
    private String name;
    private String name2;
    private Expr expr;
    private List<Statement> body;

    public PLet(String name, String name2, Expr expr, List<Statement> body, Location startPos, Location endPos) {
    	super(startPos, endPos);
    	this.name = name;
      this.name2 = name2;
		this.expr = expr;
    	this.body = body;
    }

    @Override
    public KReturn expand() {
    	List<String> params = new ArrayList<String>();
    	params.add(name);
      params.add(name2);

    	List<KStatement> kstmts = Statement.expandStatements(body);
    	KStatement kbody = KSeq.buildKSeq(kstmts, getStartPos(), getEndPos());

    	KClosure fun = new KClosure(params, kbody, getStartPos(), getEndPos());

    	List<KExpr> kargs = new ArrayList<>();
      List<KExpr> args = new ArrayList<>();
      args.add(expr.expand());
      KExpr par = new KCall(new KEVar("car", getStartPos(), getEndPos()), args, getStartPos(), getEndPos());
      KExpr pdr = new KCall(new KEVar("cdr", getStartPos(), getEndPos()), args, getStartPos(), getEndPos());
    	kargs.add(par);
      kargs.add(pdr);

    	KCall call = new KCall(fun, kargs, startPos, endPos);

    	return new KReturn(call, startPos, endPos);
    }

	@Override
	protected String buildDotGraph(DotGraph graph) {
		String letNode = graph.addNode("Let[" + name + "]");
		String exprNode = expr.buildDotGraph(graph);
		graph.addEdge(letNode, exprNode, "expr");
		for(int i=0; i<body.size(); i++) {
			Statement st = body.get(i);
			String stRoot = st.buildDotGraph(graph);
			graph.addEdge(letNode, stRoot, "body[" + i + "]");
		}
		return letNode;
	}


    @Override
    protected void prettyPrint(StringBuilder buf, int indent_level) {
    	indent(buf, indent_level);
    	buf.append("let ");
    	buf.append(name);
    	buf.append(" = ");
    	expr.prettyPrint(buf);
    	buf.append(";\n");
    	Statement.prettyPrintStatements(buf, body, indent_level);
    }
}
