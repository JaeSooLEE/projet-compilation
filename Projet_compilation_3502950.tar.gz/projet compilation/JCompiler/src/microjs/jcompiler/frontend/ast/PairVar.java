package microjs.jcompiler.frontend.ast;

import java.util.ArrayList;
import java.util.List;

import java_cup.runtime.ComplexSymbolFactory.Location;
import microjs.jcompiler.middleend.kast.KPVar;
import microjs.jcompiler.utils.DotGraph;
import microjs.jcompiler.middleend.kast.KEVar;
import microjs.jcompiler.frontend.ast.Expr;
import microjs.jcompiler.middleend.kast.KCall;
import microjs.jcompiler.middleend.kast.KExpr;





public class PairVar extends Statement {
    private String name1;
    private String name2;
    private Expr expr;

    public PairVar(String name1, String name2, Expr expr, Location startPos, Location endPos) {
    	super(startPos, endPos);
    	this.name1 = name1;
      this.name2 = name2;
		this.expr =  expr;
    }

    @Override
    public KPVar expand() {
      List<KExpr> args = new ArrayList<>();
      args.add(expr.expand());
      KExpr par = new KCall(new KEVar("car", getStartPos(), getEndPos()), args, getStartPos(), getEndPos());
      KExpr pdr = new KCall(new KEVar("cdr", getStartPos(), getEndPos()), args, getStartPos(), getEndPos());
    	return new KPVar(name1, name2, par, pdr, getStartPos(), getEndPos());
    }

	@Override
	protected String buildDotGraph(DotGraph graph) {
		String varNode = graph.addNode("Var[ " + name1 + ", " + name2 +"]");
		String exprNode = expr.buildDotGraph(graph);
		graph.addEdge(varNode, exprNode, "expr");
		return varNode;
	}


    @Override
    protected void prettyPrint(StringBuilder buf, int indent_level) {
    	indent(buf, indent_level);
    	buf.append("var [");
    	buf.append(name1);
      buf.append(", ");
      buf.append(name2);
      buf.append("] =");
    	expr.prettyPrint(buf);
    }
}
